

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression




def pre_process_data(df):

    input_df = df.fillna(0)
    # input_df['notifs_active'] = input_df['notifs_active'].mask(input_df['notifs_active'] == 0).fillna(input_df['notifs_active'].mean())
    # input_df['location_conf'] = input_df['location_conf'].mask(input_df['location_conf'] == 0).fillna(input_df['location_conf'].mean())
    # input_df['display_state'] = input_df['display_state'].mask(input_df['display_state'] == 0).fillna(input_df['display_state'].mean())
    df= input_df.drop(['ts','location_id','location_type','network_type' ], axis=1)

    print(df.head())
    print("Finished prepossessing.")

    return df





def create_training_sets(df):

    X_train, X_test, y_train, y_test = train_test_split(df.drop('system_time', axis=1),df['system_time'],test_size=0.25,
                                                                  random_state=42)
    return X_train, X_test, y_train, y_test



def train_model (X_train, y_train):
    model= LinearRegression()

    model.fit(X_train, y_train)

    return model



def run():
    df = pd.read_csv(r"C:\Users\Miltos\Desktop\ΔΙΑΧΥΤΟΣ/data.csv")

    df = pre_process_data(df)
    X_train, X_test, y_train, y_test = create_training_sets(df)

    model = train_model( X_train, y_train)
    pred = model.predict(X_test)

    print(model.score(X_test,y_test))

run()